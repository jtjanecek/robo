
from utils import utils

class ConfirmClanTeamChallengeSerializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class ConfirmClanTeamChallengeHandler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: ConfirmClanTeamChallengeHandler')

