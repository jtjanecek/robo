
from utils import utils

class CreateChannelRequest0Serializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class CreateChannelRequest0Handler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: CreateChannelRequest0Handler')

