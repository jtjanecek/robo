
from utils import utils

class CreateGameRequest0Serializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class CreateGameRequest0Handler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: CreateGameRequest0Handler')

