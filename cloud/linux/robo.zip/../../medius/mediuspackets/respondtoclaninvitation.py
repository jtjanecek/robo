
from utils import utils

class RespondToClanInvitationSerializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class RespondToClanInvitationHandler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: RespondToClanInvitationHandler')

