
from utils import utils

class GetLadderStatsWide_wIDArray_ResponseSerializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class GetLadderStatsWide_wIDArray_ResponseHandler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: GetLadderStatsWide_wIDArray_ResponseHandler')

