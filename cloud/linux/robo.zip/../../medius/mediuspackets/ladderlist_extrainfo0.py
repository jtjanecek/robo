
from utils import utils

class LadderList_ExtraInfo0Serializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class LadderList_ExtraInfo0Handler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: LadderList_ExtraInfo0Handler')

