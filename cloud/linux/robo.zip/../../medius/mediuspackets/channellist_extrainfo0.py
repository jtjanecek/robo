
from utils import utils

class ChannelList_ExtraInfo0Serializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class ChannelList_ExtraInfo0Handler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: ChannelList_ExtraInfo0Handler')

