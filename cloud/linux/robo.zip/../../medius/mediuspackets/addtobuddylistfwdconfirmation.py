
from utils import utils

class AddToBuddyListFwdConfirmationSerializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class AddToBuddyListFwdConfirmationHandler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: AddToBuddyListFwdConfirmationHandler')

