
from utils import utils

class UpdateClanLadderStatsWide_DeltaSerializer:
	data_dict = [
		{'name': 'mediusid', 'n_bytes': 2, 'cast': None}
	]

class UpdateClanLadderStatsWide_DeltaHandler:
	def process(self, serialized, monolith, con):
		raise Exception('Unimplemented Handler: UpdateClanLadderStatsWide_DeltaHandler')

