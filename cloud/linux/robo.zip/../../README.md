# To implement
Clans:
- GetMyClansHandler

Buddies:
- GetBuddyList_ExtraInfoHandler

Ignore:
- 
